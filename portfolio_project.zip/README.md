
# Portfolio Website

موقع محفظة شخصية مبني بـ HTML و CSS (Flexbox, Grid, Media Queries).

## 💡 المميزات
- واجهة متجاوبة (Responsive)
- تقسيم باستخدام Grid وFlexbox
- تصميم طبقًا لـ Figma

## 🚀 استخدام المشروع
1. استنساخ:
```bash
git clone https://github.com/اسمك/portfolio.git
```
2. فتح `index.html` في المتصفح.

## 🛠️ متطلبات
- فقط متصفح حديث (Chrome, Firefox, Safari)
